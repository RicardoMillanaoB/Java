
package paquete;


public class Automovil {

private String patente;

//falta asociaciones

Automovil(String patente){
    this.patente = patente;
}

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }
    
    

}
