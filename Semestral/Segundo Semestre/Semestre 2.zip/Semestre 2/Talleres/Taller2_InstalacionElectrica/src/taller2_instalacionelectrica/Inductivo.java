
package taller2_instalacionelectrica;


public interface Inductivo {

    
    
}
