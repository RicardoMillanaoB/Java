package taller2_instalacionelectrica;

public class Aspiradora extends AparatosElectricos implements Inductivo {

    private final double potencia = 675; // w/h; 
    private double consumo;
    private double consumoActual;

    public Aspiradora() {
        this.consumo = 0;
        this.consumoActual = 0;
    }

    
    
    @Override
    public double obtenerConsumoActual() {
        return consumoActual;
    }
    @Override
    public double obtenerPotencia() {
        return potencia;
    }

   @Override
    public double obtenerConsumo() {
       return this.consumo;
    }

    @Override
    public void encender(double tiempo) {
        this.consumo += tiempo * potencia;
        this.consumoActual = potencia;
    }

    @Override
    public void apagar() {
        this.consumoActual = 0;
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "\n           Apiradora ";
        cadena += "\n Potencia de uso por Hora: " + potencia;
        cadena += "\nConsumo: " + consumo;

        return cadena;
    }


    

}
