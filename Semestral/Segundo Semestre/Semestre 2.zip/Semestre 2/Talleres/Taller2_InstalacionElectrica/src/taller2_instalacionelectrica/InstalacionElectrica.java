
package taller2_instalacionelectrica;

import java.util.ArrayList;


public class InstalacionElectrica { 
    
    private ArrayList<AparatosElectricos> aparatos = new ArrayList<AparatosElectricos>();
    
    public void agregarAparatos(AparatosElectricos aparato){
        this.aparatos.add(aparato);
    }

    public ArrayList<AparatosElectricos> getAparatos() {
        return aparatos;
    }
    
    public double consumoActual(){
        double consumo = 0;
          for (int i = 0; i < aparatos.size(); i++) {
            if (aparatos.get(i) != null) {
                consumo += aparatos.get(i).obtenerConsumoActual()  ;
            }

        }
        
    return consumo;
    }
    
    public double consumoHora(double horas){
         double consumo = 0;

        for (int i = 0; i < aparatos.size(); i++) {
            if (aparatos.get(i) != null) {
                consumo += ((aparatos.get(i).obtenerPotencia() * horas))  ;
            }

        }
        return consumo;
    }
}
