
package taller2_instalacionelectrica;


public interface Resistivo {

   public abstract  int temperaturaBaja();
   public  abstract int  temperaturaMediana();
   public  abstract int temperaturaAlta();
}
