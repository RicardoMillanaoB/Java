package taller2_instalacionelectrica;


public class Taller2 {

    public static void main(String[] args) {
        int horas = 1;
        InstalacionElectrica instalacion = new InstalacionElectrica();
        
        Plancha plancha = new Plancha();
        Aspiradora aspiradora = new Aspiradora();
        Televisor televisor = new Televisor();
        
        instalacion.agregarAparatos(plancha);
        instalacion.agregarAparatos(aspiradora);
        instalacion.agregarAparatos(televisor);
        
        RegistroConsumo registro = new RegistroConsumo();
        System.out.println("Consumo actual: " +instalacion.consumoActual());
        
        
        aspiradora.encender(horas); //tiempo = horas
        plancha.encender(horas);
        
        System.out.println("Consumo Aparatos: "+ instalacion.consumoHora(horas)+"w/h");
        System.out.println("Consumo Aparatos: $"+ registro.consumoHoras(instalacion,horas));
        
        plancha.apagar();
        televisor.encender(horas);
        
              System.out.println("Consumo Aparatos: "+ instalacion.consumoHora(horas)+"w/h");
              System.out.println("Consumo Aparatos: $"+ registro.consumoHoras(instalacion,horas));
        
              //fin taller
    }

}
