package taller2_instalacionelectrica;

public class Televisor extends AparatosElectricos implements Electronico {

    private final double potencia = 760; //w/h
    private final double consumoPasivo = Electronico.consumoPasivo;
    private double consumo;
    private double consumoActual;

    Televisor() {
        this.consumo = 0;
        this.consumoActual = 0;
    }

    public double getConsumoActual() {
        return consumoActual;
    }

    public void setConsumoActual(double consumoActual) {
        this.consumoActual = consumoActual;
    }

    @Override
    public double obtenerConsumoActual() {
        return consumoActual;
    }

    @Override
    public double obtenerPotencia() {
        return potencia;
    }

    @Override
    public double obtenerConsumo() {
        return this.consumo;
    }

    @Override
    public void encender(double tiempo) {
        this.consumoActual += potencia;
        this.consumo = potencia * consumoPasivo * tiempo;
    }

    @Override
    public void apagar() {
        this.consumoActual = consumoPasivo;
        this.consumo += consumoPasivo;
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "\n           Televisor ";
        cadena += "\n Potencia de uso por Hora: " + potencia;
        cadena += "\nConsumo Pasivo: " + consumoPasivo;
        cadena += "\nConsumo: " + consumo;
        cadena += "\nConsumo Actual: " + consumoActual;
        return cadena;
    }

}
