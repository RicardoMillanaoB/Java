package taller2_instalacionelectrica;

public class Plancha extends AparatosElectricos implements Resistivo {

    private final double potencia = 1000;//w/h
    private int temperaturaActual;
    private double consumo;
    private double consumoActual;

    public Plancha() {
        this.temperaturaActual =0;
        this.consumo = 0;
        this.consumoActual = 0;
    }

    
    public int getTemperaturaActual() {
        return temperaturaActual;
    }

    public void setTemperaturaActual(int temperaturaActual) {
        this.temperaturaActual = temperaturaActual;
    }
  @Override
    public double obtenerConsumoActual() {
        return consumoActual;
    }
    @Override
    public double obtenerPotencia() {
       return potencia;
    }
       @Override
    public double obtenerConsumo() {
        return this.consumo;
    }

    @Override
    public void encender(double tiempo) {
        this.consumo += tiempo * potencia;
        this.consumoActual = potencia;
    }

    @Override
    public void apagar() {
        this.consumoActual = 0;
    }

    @Override
    public int temperaturaBaja() {
        return 30;
    }

    @Override
    public int temperaturaMediana() {
        return 50;
    }

    @Override
    public int temperaturaAlta() {
        return 70;
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "\n           Plancha ";
        cadena += "\n Potencia de uso por Hora: " + potencia;
        cadena += "\nTemperatura Actual: " + temperaturaActual;
        cadena += "\nConsumo: " + consumo;

        return cadena;
    }

  

    }

 


