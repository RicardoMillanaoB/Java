package taller2_instalacionelectrica;

public class RegistroConsumo {

    public double consumoTotal(InstalacionElectrica instalacion) {

        double consumo = 0;

        for (int i = 0; i < instalacion.getAparatos().size(); i++) {
            if (instalacion.getAparatos().get(i) != null) {
                consumo += ((instalacion.getAparatos().get(i).obtenerConsumo()) / 1000) * 100;
            }

        }
        return consumo;
    }

    public double consumoHoras(InstalacionElectrica instalacion, double horas) {

        double consumo = 0;

        for (int i = 0; i < instalacion.getAparatos().size(); i++) {
            if (instalacion.getAparatos().get(i) != null) {
                consumo += ((instalacion.getAparatos().get(i).obtenerPotencia() * horas) / 1000) * 100;
            }

        }
        return consumo;
    }

}
