
package taller2_instalacionelectrica;


public interface Electronico {

    public double consumoPasivo = 200;
}
