
package taller2_instalacionelectrica;


public abstract class AparatosElectricos {
    
    public abstract void encender(double tiempo);
    public abstract void apagar();
    public abstract double obtenerPotencia();
    public abstract double obtenerConsumo();
    public abstract double obtenerConsumoActual();
    
    
    
}
