package Aparatos;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class Aspiradora extends AparatosElectronicos {

    private boolean estadoActual;

    private double consumo;
    private long tiempoConsumo;
    private LocalDateTime tiempoInicio;
    private LocalDateTime tiempoTermino;

    public Aspiradora(String tipoAparato, double potencia) {
        super(tipoAparato, potencia);
        super.estadoActual = estadoActual;
        this.consumo = 0;
        this.tiempoConsumo = 0;

    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }

    public String getTipoAparato() {
        return tipoAparato;
    }

    public double potencia() {
        return super.potencia;
    }

    @Override
    public void estadoActual() {
     
        System.out.println("Aparato electronico: " + this.getClass().getSimpleName());
        System.out.println("____Estado____");
        if (estadoActual == true) {
            System.out.println("Encendido");
          
           

        } else {
            System.out.println("Apagado");
           
        }
        System.out.println("Consumo por hora: " + potencia + " watt/hora");
       System.out.println("Consumido: " + consumo);
        System.out.println("Tiempo consumo: " + tiempoConsumo);
    }

    @Override
    public void encender() {
        this.estadoActual = true;
        System.out.println("Aparato electronico" + this.getClass().getSimpleName() + "  se acaba de encender");

        this.tiempoInicio = LocalDateTime.now();
    }

    @Override
    public void apagar() {
        this.estadoActual = false;
        System.out.println("Aparato electronico" + this.getClass().getSimpleName() + "  se acaba de apagar");

        this.tiempoTermino = LocalDateTime.now();
        this.tiempoConsumo += this.tiempoInicio.until(tiempoTermino, ChronoUnit.SECONDS);
        this.tiempoInicio = null;
        this.tiempoTermino = null;
    }

    @Override
    public double consumoAparatos() {
        return this.consumo;
    }

    @Override
    public double tiempoConsumo() {
        return this.tiempoConsumo();
    }

}
