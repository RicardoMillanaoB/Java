package Instalacion;

import Aparatos.*;
import java.util.ArrayList;

public class Medidor {

    public final int precioEnergia = 100;

    public Medidor() {
    }

    public void medidor(ArrayList<AparatosElectronicos> listaAparatos) {// ?
        double consumo = 0;
        for (int i = 0; i < listaAparatos.size(); i++) {
            listaAparatos.get(i).estadoActual();
            System.out.println("Consumo total: " + consumoTotal(listaAparatos));
        }
    }
    public double  consumoTotal(ArrayList<AparatosElectronicos> listaAparatos){
        double consumo = 0;
        for (int i = 0; i < listaAparatos.size(); i++) {
            consumo+=listaAparatos.get(i).consumoAparatos();
        }
        return consumo;
    }
    public double gasto(ArrayList<AparatosElectronicos> listaAparatos, double tiempo){
       
        return tiempo*(consumoTotal(listaAparatos)/100)*precioEnergia;
    }
}
