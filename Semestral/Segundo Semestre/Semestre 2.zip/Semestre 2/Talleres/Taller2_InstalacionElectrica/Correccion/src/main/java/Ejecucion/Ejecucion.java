package Ejecucion;

import Aparatos.*;
import Instalacion.*;
import java.time.Clock;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
public class Ejecucion {

    public static void main(String[] args) {
        ArrayList<AparatosElectronicos> listaAparatos = new ArrayList<>();

        AparatosElectronicos plancha = new Plancha(TipoAparatos.Resistivo.getTipo(), 1000);
        AparatosElectronicos aspiradora = new Aspiradora(TipoAparatos.Inductivo.getTipo(), 675);
        AparatosElectronicos televisor = new Televisor(TipoAparatos.Electronico.getTipo(), 760);

        listaAparatos.add(plancha);
        listaAparatos.add(aspiradora);
        listaAparatos.add(televisor);
        
        plancha.encender();
        aspiradora.encender();
        televisor.encender();
        for(int i = 0; i < 100000; i++){
            System.out.println(".");
            System.out.print("  .   ..  .   .   ..  .   ..  .   .   .   ..  .   .   ..  .   .   .   .-  .   .   .   .   .   .   .   ..  .   .   .   .   ..  ");
        }
        
        plancha.apagar();
        aspiradora.apagar();
        Medidor medid = new Medidor();
        medid.medidor(listaAparatos);
    }

}
