package Aparatos;


public abstract class AparatosElectronicos implements Encendible{
    
   protected String tipoAparato;
   protected double potencia;
   protected boolean estadoActual;
 
   
   AparatosElectronicos(String tipoAparato, double potencia){
       this.tipoAparato = tipoAparato;
       this.potencia = potencia;
       this.estadoActual = false;
   }
   public abstract double consumoAparatos();
   public abstract double tiempoConsumo();
    public abstract void estadoActual();
    
}
