
package Aparatos;

public enum TipoAparatos {
    
    Resistivo("resistivo"),
    Inductivo("inductivo"),
    Electronico("Electronico");
    
    private final String tipo;
  
    TipoAparatos(String tipo){
        this.tipo = tipo;
    }
    public String getTipo(){
        return tipo;
    }
    
}
