package Aparatos;


public interface Encendible{
    
   
    public void encender();
    public void apagar();
  
}
