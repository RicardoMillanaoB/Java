package pkg7.pkg1.interfaces_caballo.de.trolla;

public class Griego extends Guerrero {

    private String nacionalidad;
    private String nombre;
    private int fuerza;

    Griego(String nacionalidad, String nombre, int fuerza) {
        this.nacionalidad = nacionalidad;
        this.nombre = nombre;
        this.fuerza = fuerza;

    }

    public String getNombre() {
        return this.nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public int getFuerza() {
        return fuerza;
    }

    @Override
    public boolean isGriego(Guerrero guerrero[]) {
        int cont = 0;
        for (int i = 0; i < guerrero.length; i++) {
            if (guerrero[i] instanceof Griego) {
                cont++;
            }
        }
        if (cont == guerrero.length) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isRomano(Guerrero guerrero[]) {

        int cont = 0;
        for (int i = 0; i < guerrero.length; i++) {
            if (guerrero[i] instanceof Romano) {
                cont++;
            }
        }
        if (cont == guerrero.length) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString(){
        return "\nGuerrero: "+this.nombre + "\nFuerza: "+this.fuerza;
    }
}
