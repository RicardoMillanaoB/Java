
package pkg7.pkg1.interfaces_caballo.de.trolla;


public interface PuedeMontarse {

    public abstract int montar(Guerrero g);
    public abstract void desmontar();
    
}
