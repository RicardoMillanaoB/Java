package pkg7.pkg1.interfaces_caballo.de.trolla;

public enum Nacionalidad {

    GRIEGA("Griego"), ROMANA("Romano");

    private final String nacionalidad;

    Nacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getNacionalidad() {
        return this.nacionalidad;
    }
}
