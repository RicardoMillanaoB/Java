package pkg7.pkg1.interfaces_caballo.de.trolla;

public class Interfaces_CaballoDeTrolla {

    public static void main(String[] args) {

        Guerrero griego1 = new Griego(Nacionalidad.GRIEGA.getNacionalidad(),"Griego1", Fuerza.ALTA.getFuerza() );
        Guerrero griego2 = new Griego(Nacionalidad.GRIEGA.getNacionalidad(), "Griego2",  Fuerza.MEDIANA.getFuerza());
        Guerrero griego3 = new Griego(Nacionalidad.GRIEGA.getNacionalidad(), "Griego3", Fuerza.DESCOMUNAL.getFuerza());

        Guerrero romano1 = new Romano(Nacionalidad.ROMANA.getNacionalidad(),"Romano1",Fuerza.MEDIANA.getFuerza() );
        Guerrero romano2 = new Romano(Nacionalidad.ROMANA.getNacionalidad(),"Romano2",Fuerza.ALTA.getFuerza());
        Guerrero romano3 = new Romano(Nacionalidad.ROMANA.getNacionalidad(), "Romano3", Fuerza.DESCOMUNAL.getFuerza());

        //Creacion del "Ejercito" de guerreros
        Guerrero guerreros[] = new Guerrero[3];
        guerreros[0] = griego3;
        guerreros[1] = griego1;
        guerreros[2] = griego2;
        
        //Creacion de el caballo
        Caballo troyano = new Caballo(guerreros[1] , 10);
        System.out.println(troyano.imprimirCaballo());
        System.out.println(troyano.montar(griego2));
        System.out.println(troyano.imprimirCaballo());

       

    }

}
