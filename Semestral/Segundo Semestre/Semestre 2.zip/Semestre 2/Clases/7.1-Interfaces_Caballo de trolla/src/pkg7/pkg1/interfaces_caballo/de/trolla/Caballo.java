package pkg7.pkg1.interfaces_caballo.de.trolla;

public class Caballo implements PuedeMontarse {

    public int capacidad;
    public int ocupacion;
    public Guerrero ocupantes[];

    Caballo(Guerrero guerrero[]) {
        if (guerrero[0].isGriego(guerrero) == true) {
            this.capacidad = guerrero.length;
            this.ocupacion = guerrero.length;
            this.ocupantes = new Guerrero[capacidad];
            this.ocupantes = guerrero;
        } else {
            this.capacidad = 100;
            this.ocupacion = 0;
            this.ocupantes = new Guerrero[capacidad];

        }
    }

    Caballo(Guerrero guerrero, int capacidad) {
        if (guerrero.getClass().getSimpleName().equalsIgnoreCase("Griego")) {
            this.capacidad = capacidad;
            this.ocupacion = 1;
            this.ocupantes = new Guerrero[capacidad];
            this.ocupantes[0] = guerrero;
        } else {
            this.capacidad = capacidad;
            this.ocupacion = 0;
            this.ocupantes = new Guerrero[capacidad];
        }
    }

    public int getCapacidad() {
        return capacidad;
    }

    public int getOcupacion() {
        return ocupacion;
    }

    public Guerrero[] getOcupantes() {
        return ocupantes;
    }

    public void ordenar() {

        if (this.ocupantes[0] != null) {
            Guerrero aux[] = new Guerrero[1];
            for (int i = 0; i < this.ocupantes.length; i++) {
                for (int j = 0; j < this.ocupantes.length - 1; j++) {
                    if (((Griego) this.ocupantes[j]).getFuerza() > ((Griego) this.ocupantes[j + 1]).getFuerza()) {
                        aux[0] = this.ocupantes[j];
                        this.ocupantes[j] = this.ocupantes[j + 1];
                        this.ocupantes[j + 1] = aux[0];
                    }
                }
            }
        }
    }

    public int intBuscar(String nombre) {
        ordenar(); //requerimieto de la pregunta
        for (int i = 0; i < this.ocupantes.length; i++) {
            if (((Griego) ocupantes[i]).getNombre().equalsIgnoreCase(nombre)) {
                return i + 1;
            }

        }
        return -1;

    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "\n=======    Caballo     =========";
        cadena += "\n         Ocupantes: ";

        if (this.ocupantes[0] != null) {
            for (int i = 0; i < this.ocupantes.length; i++) {

                if (this.ocupantes[i] != null) {

                    cadena += "'\n" + i + ") " + ((Griego) this.ocupantes[i]).toString();

                }
            }
        }

        cadena += "\nCapacidad: " + capacidad + "\nOcupacion: " + ocupacion;

        return cadena;
    }

    //implementacion de la interfaz
    @Override
    public int montar(Guerrero g) {
        if (g instanceof Griego) {

            for (int i = 0; i < this.ocupantes.length; i++) {
                if (this.ocupantes[i] == null) {
                    this.ocupantes[i] = g;
                    this.ocupacion++;
                    System.out.println("Ocupantes: ");
                    return this.ocupacion;

                }
            }

        } else if (g instanceof Romano) {
            return -2;
        }
        return -1;
    }

    @Override
    public void desmontar() {
        this.ocupacion = 0;
        this.ocupantes = null;
    }

    public String imprimirCaballo() {
        String cadena = "";
        for (int i = 0; i < this.capacidad; i++) {
            if (this.ocupantes[i] != null) {
                cadena += ((Griego) this.ocupantes[i]).toString();
            }
        }
        return cadena;
    }

}
