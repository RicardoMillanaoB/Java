package pkg7.pkg1.interfaces_caballo.de.trolla;

public class Romano extends Guerrero {

    private String nacionalidad;
   private String nombre;
   private int fuerza;

    Romano(String nacionalidad,String nombre, int fuerza) {
        this.nacionalidad = nacionalidad;
        this.nombre = nombre;
        this.fuerza = fuerza;
    }

    public String getNacionalidad() {
        return this.nacionalidad;
    }

    public String getNombre() {
        return nombre;
    }

    public int getFuerza() {
        return fuerza;
    }
    

    public boolean isGriego(Object guerrero) {
        guerrero = (Guerrero) guerrero;

        if (guerrero instanceof Griego) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isRomano(Guerrero guerrero[]) {

        int cont = 0;
        for (int i = 0; i < guerrero.length; i++) {
            if (guerrero[i] instanceof Romano) {
                cont++;
            }
        }
        if (cont == guerrero.length) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean isGriego(Guerrero guerrero[]) {
        int cont = 0;
        for (int i = 0; i < guerrero.length; i++) {
            if (guerrero[i] instanceof Griego) {
                cont++;
            }
        }
        if (cont == guerrero.length) {
            return true;
        } else {
            return false;
        }
    }
}
