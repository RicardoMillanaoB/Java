
package pkg7.pkg1.interfaces_caballo.de.trolla;


public abstract class Guerrero {

    public abstract boolean isGriego(Guerrero guerrero []);
    public abstract boolean isRomano(Guerrero guerrero []);
    
}
