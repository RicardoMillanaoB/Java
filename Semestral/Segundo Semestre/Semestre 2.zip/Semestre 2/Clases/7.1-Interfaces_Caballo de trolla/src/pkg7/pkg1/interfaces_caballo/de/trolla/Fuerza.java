
package pkg7.pkg1.interfaces_caballo.de.trolla;


public enum Fuerza {

    MEDIANA(10),ALTA(15),DESCOMUNAL(20);
    
    public final int fuerza;
    
    Fuerza(int fuerza){
        this.fuerza  = fuerza;
    }

    public int getFuerza() {
        return fuerza;
    }
    
    
}
