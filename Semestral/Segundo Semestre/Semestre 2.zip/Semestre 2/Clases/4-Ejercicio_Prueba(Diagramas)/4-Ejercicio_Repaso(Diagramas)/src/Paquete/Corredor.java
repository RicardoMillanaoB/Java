/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Paquete;

/**
 *
 * @author Ricardo
 */
public class Corredor {
    public static void main(String args []){
        Venta venta1 = new Venta(cuenta1, producto1,boleta1,juan);
        Vendedor juan = new Vendedor("Juan","23234234-1"," 1 de julio de 2012",23424);
        Cliente cliente1 = new Cliente("Pedro garzua","343434-3","#$");
        
      Boleta boleta1 = new Boleta(334,434,233,venta1);
        Cuenta cuenta1 = new Cuenta(cliente1,venta1);
        Producto producto1 = new Producto("Triton","Galleta rellena de vainilla",500,200);
        
        
       
    }
}
