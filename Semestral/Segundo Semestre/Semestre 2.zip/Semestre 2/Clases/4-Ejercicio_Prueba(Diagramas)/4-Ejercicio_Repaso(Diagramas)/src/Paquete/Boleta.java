package Paquete;

public class Boleta {
    
    private int idBoleta;
    private int subtotal;
    private int total;
    private double descuento;
    
    private Venta compra;
    
    Boleta(int subtotal, int total,double descuento, Venta venta){
        this.subtotal = subtotal;
        this.total = total;
        this.descuento = descuento;
        
        this.compra = venta;
    }
}
