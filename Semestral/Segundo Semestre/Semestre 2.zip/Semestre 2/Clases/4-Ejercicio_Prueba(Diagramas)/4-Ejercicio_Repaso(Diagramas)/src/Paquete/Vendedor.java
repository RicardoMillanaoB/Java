package Paquete;
import java.util.ArrayList;
public class Vendedor {
    
    private String nombre;
    private String rut;
    private String fechaNacimiento;
    private int sueldo;
    
    private ArrayList <Venta> ventas;
    
    Vendedor(String nombre,String rut,String fechaNacimiento,int sueldo){
        this.nombre = nombre;
        this.rut = rut;
        this.fechaNacimiento = fechaNacimiento;
        
        this.ventas = new ArrayList<>() ;
    }
}
