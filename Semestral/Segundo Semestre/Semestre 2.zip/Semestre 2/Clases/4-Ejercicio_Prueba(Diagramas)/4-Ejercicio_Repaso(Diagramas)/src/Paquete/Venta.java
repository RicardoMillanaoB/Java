package Paquete;
import java.util.ArrayList;

public class Venta {
    
    private int idVenta;
    
    private static int cont;
    private Cuenta cuentaCliente;
    private ArrayList <Producto> productos = new ArrayList <Producto>();
    private Boleta boleta;
    private Vendedor vendedor;
    
    Venta(Cuenta cuenta,Producto producto,Boleta boleta, Vendedor vendedor){
        this.idVenta = cont++;
        
        this.cuentaCliente = cuenta;
     
        this.boleta = boleta;
        this.vendedor = vendedor;
    }

    public int getIdVenta() {
        throw new UnsupportedOperationException("HOlaa");
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public Cuenta getCuentaCliente() {
        return cuentaCliente;
    }

    public void setCuentaCliente(Cuenta cuentaCliente) {
        this.cuentaCliente = cuentaCliente;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    public Boleta getBoleta() {
        return boleta;
    }

    public void setBoleta(Boleta boleta) {
        this.boleta = boleta;
    }

    public Vendedor getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }
    
}
