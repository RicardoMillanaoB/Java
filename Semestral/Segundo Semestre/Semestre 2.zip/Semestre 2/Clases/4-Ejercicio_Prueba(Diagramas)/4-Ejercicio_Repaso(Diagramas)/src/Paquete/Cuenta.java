
package Paquete;

import java.util.ArrayList;


public class Cuenta {
    
    private int idCuenta;
    
   private static int cont; 
   private  Cliente cliente;
   private ArrayList <Venta> compras = new ArrayList<>();
   
   Cuenta(Cliente cliente,Venta venta){
       this.idCuenta = cont++;
       this.cliente = cliente;
       
      
   }
   public void añadirCompras(Venta venta){
       this.compras.add(venta);
   }
}
