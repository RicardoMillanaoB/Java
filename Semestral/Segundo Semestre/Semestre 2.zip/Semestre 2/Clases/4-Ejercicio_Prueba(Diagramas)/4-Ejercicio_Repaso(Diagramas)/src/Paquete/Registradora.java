package Paquete;

import java.util.ArrayList;


public class Registradora {
    
    Registradora(){}
    
    public void calcularSubtotal(ArrayList<Producto> producto){
    
        double subtotal = 0;
        
        for(int i = 0; i < producto.size()-1; i++){
            if(producto.get(i) != null){
                subtotal += producto.get(i).getPrecio();
            }
        }
    
    }
    
}
