package Paquete;

public class Cliente {
    
    private String nombre;
    private String rut;
    private String fechaNacimiento;
    
    private Cuenta cuentas [] = new Cuenta [3] ;//de 1 a 3  cuentas
    
    Cliente(String nombre, String rut, String fechaNacimiento){
        this.nombre = nombre;
        this.rut = rut;
        this.fechaNacimiento = fechaNacimiento;
        
    }
    public void añadirCuenta(Cuenta cuenta){
        for(int i = 0; i < 3 ; i++){
            if(this.cuentas[i] == null){
                this.cuentas[i] = cuenta;
            }else{
                System.out.println("Cliente no puede tener mas de tres cuenta");
                return;
            }
        }
    }
}
