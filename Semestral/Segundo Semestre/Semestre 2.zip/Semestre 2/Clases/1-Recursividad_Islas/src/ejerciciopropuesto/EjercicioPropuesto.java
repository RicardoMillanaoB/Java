package ejerciciopropuesto;

import java.util.Random;

public class EjercicioPropuesto {

    public static void main(String[] args) {

        int mapa[][] = new int[6][6];
        int mapaOpuesto[][] = new int[6][6];
        llenarMapa(mapa);
        imprimirMapa(mapa);
        asociacionMapas(mapa, mapaOpuesto);
        System.out.println("\n");
        cambioMapaOpuesto(mapaOpuesto);
        arreglador(mapaOpuesto);
        imprimirMapaOpuesto(mapaOpuesto);
        System.out.println("\nEl numero de islas es " + numeroIslas(mapaOpuesto));
        imprimePosicion(mapaOpuesto);

    }

    public static void llenarMapa(int mapa[][]) {
        Random random = new Random();
        for (int i = 0; i < mapa[0].length; i++) {
            for (int j = 0; j < mapa[0].length; j++) {
                mapa[i][j] = random.nextInt(2) + 0;
            }
        }
    }

    public static void imprimirMapa(int mapa[][]) {

        for (int i = 0; i < mapa[0].length; i++) {
            System.out.println("");
            for (int j = 0; j < mapa[0].length; j++) {
                if (mapa[i][j] == 0) {
                    System.out.print(" [ ] ");
                    continue;
                } else {
                    System.out.print(" [" + mapa[i][j] + "] ");
                }
            }
        }
    }

    public static void asociacionMapas(int mapaOpuesto[][], int mapa[][]) {
        int barcos = 0;

        for (int i = 0; i < mapaOpuesto.length; i++) {
            for (int j = 0; j < mapaOpuesto[0].length; j++) {
                mapa[i][j] = mapaOpuesto[i][j];
            }
        }

    }

    public static void imprimirMapaOpuesto(int mapaOpuesto[][]) {

        for (int i = 0; i < mapaOpuesto.length; i++) {
            System.out.println("");
            for (int j = 0; j < mapaOpuesto[0].length; j++) {
                if (mapaOpuesto[i][j] == 0) {
                    System.out.print("\t[  ]\t");
                    continue;
                } else {
                    System.out.print("\t[" + mapaOpuesto[i][j] + "]\t");
                }
            }
        }
    }

    public static void cambioMapaOpuesto(int mapaOpuesto[][]) {
        int cont = 0;
        for (int i = 0; i < mapaOpuesto.length; i++) {
            for (int j = 0; j < mapaOpuesto[0].length; j++) {
                if (mapaOpuesto[i][j] == 1) {

                    cont++;
                    mapaOpuesto[i][j] = cont;

                    exploradorVertical(i, j, mapaOpuesto, cont);
                    exploradorDerecha(i, j, mapaOpuesto, cont);

                }

            }
        }
    }

    public static void exploradorVertical(int i, int j, int mapaOpuesto[][], int cont) {
        if (i < mapaOpuesto.length - 1 && mapaOpuesto[i + 1][j] == 1) {
            mapaOpuesto[i + 1][j] = cont;

            exploradorDerecha(i + 1, j, mapaOpuesto, cont);
            exploradorVertical(i + 1, j, mapaOpuesto, cont);
            exploradorIzquierda(i + 1, j, mapaOpuesto, cont);

        }
    }

    public static void exploradorDerecha(int i, int j, int mapaOpuesto[][], int cont) {

        if (j < mapaOpuesto.length - 1 && mapaOpuesto[i][j + 1] == 1) {
            mapaOpuesto[i][j + 1] = cont;

            exploradorDerecha(i, j + 1, mapaOpuesto, cont);
            exploradorVertical(i, j + 1, mapaOpuesto, cont);

        }
    }

    public static void exploradorIzquierda(int i, int j, int mapaOpuesto[][], int cont) {
        if (j > 0 && mapaOpuesto[i][j - 1] == 1) {
            mapaOpuesto[i][j - 1] = cont;

            exploradorDerecha(i, j - 1, mapaOpuesto, cont);
            exploradorVertical(i, j - 1, mapaOpuesto, cont);
        }
    }

    public static int numeroIslas(int mapaOpuesto[][]) {
        int islas = 0;

        for (int i = 0; i < mapaOpuesto.length; i++) {
            for (int j = 0; j < mapaOpuesto.length; j++) {
                if (mapaOpuesto[i][j] > islas) {
                    islas = mapaOpuesto[i][j];
                }
            }
        }

        return islas;
    }

    public static void arreglador(int mapaOpuesto[][]) {
        for (int i = 0; i < mapaOpuesto.length; i++) {
            for (int j = 0; j < mapaOpuesto[0].length; j++) {
                if (mapaOpuesto[i][j] == 1 && mapaOpuesto[i][j + 1] > 1) {
                    mapaOpuesto[i][j] = mapaOpuesto[i][j + 1];
                } else {
                    if (mapaOpuesto[i][j] == 1 && mapaOpuesto[i + 1][j] > 1) {
                        mapaOpuesto[i][j] = mapaOpuesto[i + 1][j];
                    }
                }
            }
        }
    }

    public static int cuentaUnionIslas(int mapaOpuesto[][], int numIslaOpuesta) {
        int islasUnidas = 0;

        for (int i = 0; i < mapaOpuesto.length; i++) {
            for (int j = 0; j < mapaOpuesto[0].length; j++) {
                if (mapaOpuesto[i][j] == numIslaOpuesta) {
                    islasUnidas++;
                }
            }
        }
        return islasUnidas;
    }

    public static void imprimePosicion(int mapaOpuesto[][]) {
        int cont = 0;
        int isla = 0;
        for (int l = 0; l < numeroIslas(mapaOpuesto); l++) {
            cont++;
             System.out.println("Isla " + cont);
            for (int i = 0; i < mapaOpuesto.length; i++) {

                for (int j = 0; j < mapaOpuesto.length; j++) {
//                for (int k = 0; k < mapaOpuesto[0].length; k++) {
                    // isla "2", isla "3"
//                    for(int l = 0; l < cuentaUnionIslas(mapaOpuesto, cont); l++){ //supuesto de 3 islas unidas, recorrerá y buscaras i y j
                  

                    if (mapaOpuesto[i][j] == cont) {
                       
                        System.out.println("  (" + i + "," + j + ")");
                    }
                }
//                }

//                    }
            }
        }
    }
}
