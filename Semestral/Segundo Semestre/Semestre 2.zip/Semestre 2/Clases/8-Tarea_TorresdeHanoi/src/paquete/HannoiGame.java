package paquete;

public class HannoiGame {

    TowerList tower1 = new TowerList(1);
    TowerList tower2 = new TowerList(2);
    TowerList tower3 = new TowerList(3);

    Disk disco1;
    Disk disco2;
    Disk disco3;
    Disk disco4;
    Disk disco5;
    Disk disco6;
    Disk disco7;

    HannoiGame() {
        this.disco1 = new Disk(Tamaño.UNO.getTamaño());
        this.disco2 = new Disk(Tamaño.DOS.getTamaño());
        this.disco3 = new Disk(Tamaño.TRES.getTamaño());
        this.disco4 = new Disk(Tamaño.CUATRO.getTamaño());
        this.disco5 = new Disk(Tamaño.CINCO.getTamaño());
        this.disco6 = new Disk(Tamaño.SEIS.getTamaño());
        this.disco7 = new Disk(Tamaño.SIETE.getTamaño());
    }

    public void iniciarJuego() {

        tower1.add(disco1);
        tower1.add(disco2);
        tower1.add(disco3);
        tower1.add(disco4);
        tower1.add(disco5);
        tower1.add(disco6);
        tower1.add(disco7);

        juegoAutomatico(disco7, tower1, tower2, tower3);

        System.out.println(tower3.toString());
    }

    public void moverDisco(Disk disco, TowerList origen, TowerList destino) {
        
        destino.add(origen.peek(disco));
        System.out.println("Se ha movido el disco n° " + disco.getNumero() + " de torre: |" + origen.getNumero() + "| a  torre: |" + destino.getNumero()+"|");
    }

    public void juegoAutomatico(Disk disco, TowerList origen, TowerList auxiliar, TowerList destino) {

 
            if (disco.getNumero() == 1) { 

                moverDisco(disco, origen, destino);
               

            } else {

                juegoAutomatico(origen.get(disco.getNumero()-1), origen, destino, auxiliar);//error de referencia, revisé mucho  el error pero no  veo la forma de arreglarlo

                moverDisco(disco, origen, destino);
                
               juegoAutomatico(origen.get(disco.getNumero()-1), auxiliar, origen, destino);//error de referencia

                 
            }

            
        
    }
    
}

