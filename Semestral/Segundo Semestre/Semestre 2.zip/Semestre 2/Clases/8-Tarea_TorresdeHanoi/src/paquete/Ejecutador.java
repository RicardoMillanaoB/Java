package paquete;


public class Ejecutador {

   public static void main(String [] args){
       
       HannoiGame game = new HannoiGame();
       
       game.iniciarJuego();

//    Hanoi(7,1,2,3);
       
    }

   public static void Hanoi(int n, int origen,  int auxiliar, int destino){
  if(n==1)
  System.out.println("mover disco " + n+" de " + origen + " a " + destino);
  else{
     Hanoi(n-1, origen, destino, auxiliar);
     System.out.println("mover disco de "+ origen + " a " + destino);
     Hanoi(n-1, auxiliar, origen, destino);
   }
 }

}
