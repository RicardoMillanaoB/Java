package paquete;

public class TowerList implements OwnList<TowerList> {

    private Disk discos[];

    private int numero;

    TowerList(int numero) {
        this.numero = numero;
        this.discos = new Disk[7];
    }

    public Disk[] getDiscos() {
        return discos;
    }

    public int getNumero() {
        return this.numero;
    }

    @Override
    public int size() {
        int cont = 0;
        for (int i = 0; i < discos.length; i++) {
            if (this.discos[i] != null) {
                cont++;
            }
        }
        return cont;
    }

    @Override
    public boolean isEmpty() {
        int cont = 0;
        for (int i = 0; i < discos.length; i++) {
            if (this.discos[i] != null) {
                cont++;
            }
        }

        if (cont == 0) {
            return false;
        } else {
            return true;
        }

    }

    @Override
    public boolean contains(Disk tObject) {
        int cont = 0;
        for (int i = 0; i < discos.length; i++) {
            if (this.discos[i].getNumero() == tObject.getNumero()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public TowerList[] toArray() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean add(Disk tObject) { //comprobacion de disco menor
        for (int i = 0; i < 7; i++) {

            if (this.discos[i] == null) {

                this.discos[i] = tObject;
                return true;

            }

        }
        return false;

    }

    @Override
    public Disk peek(Disk tObject) {

       

        if (tObject.getNumero() > 0 && tObject.getNumero() < 8) {
            for (int i = 0; i < this.discos.length; i++) {
                if (this.discos[i] != null) {
                    if (this.discos[i].getNumero() == tObject.getNumero()) {

                        this.discos[i] = null;
                        return tObject;
                    }

                }
            }
        }else
        if (tObject.getNumero() > 8) {
            for (int i = 7; i < 0; i--) {
                if (this.discos[i] != null) {

                    this.discos[i] = null;
                    return tObject;

                }
            }
        } else {
            for (int i = 0; i < discos.length; i++) {
                if (discos[i] != null) {
                    this.discos[i] = null;
                    return tObject;
                }
            }
     
        }
    return discos[7]; // 7 nulo
    }

    @Override
    public void clear() {
        this.discos = null;
    }

    @Override
    public Disk get(int index) { //devuelve el disco 

        if (index > 0 && index < 8) {
            for (int i = 0; i < this.discos.length; i++) {
                if (this.discos[i] != null) {
                    if (this.discos[i].getNumero() == index) {
                        return discos[i];
                    }

                }
            }
        }
        if (index > 7) {
            for (int i = 8; i < 0; i--) {
                if (discos[i] != null) {
                    return discos[i];
                }
            }
        } else {
            for (int i = 0; i < discos.length; i++) {
                if (discos[i] != null) {
                    return discos[i];
                }
            }
        }
       return discos[7]; // 7 nulo
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "\n==========( " + this.getNumero() + " )==========";

        for (int i = 0; i < this.discos.length; i++) {
            if (this.discos[i] != null) {
                cadena += "\n" + this.discos[i].getNumero();
            }
        }

        return cadena;
    }

    public Disk obtenerUltimoDisco() {
        for (int i = 0; i < this.discos.length; i++) {
            if (this.discos[i] != null) {
                return this.discos[i];
            }
        }
        return this.discos[1];
    }
}
