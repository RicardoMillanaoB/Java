
package paquete;


public class Disk{

    private int numero;
    
    Disk(int numero){
        this.numero = numero;
    }

    public int getNumero() {
        return numero;
    }
    
}
