
package paquete;

public interface OwnList <T> {
    
    public abstract int size();//retorna el tamaño
    
    public abstract boolean isEmpty();//retorna boolean de estar vacia
    
    public abstract boolean contains(Disk Object); // verifiva si contiene el objeto tObject dento de la lista
    
    public T[] toArray(); // Transforma la lista a arreglo
    
    public boolean add(Disk tObject); //agrega el tObjext a la lista según las reglas
    
    public Disk peek(Disk tObject);// remueve el elemento de la lista segun las reglasy lo retorna
    
    public void clear();// Limpia la lista
    
    public Disk get(int index); // obtienne le elemento con indice 
    
}
