
public class Master {

    public static void main(String[] args) {

        Casa casa1 = new Casa("Rojo", 5, 2);
        Casa casa2 = new Casa("Verde", 3, 1);

        if(casa1.esIgual(casa2)){
            System.out.println("La casa es igual");
        }else{
            System.out.println("La casa no es igual");
        }
        
         if(casa1.esMayor(casa2)){ // en el argumento se ve que clase se evalua
            System.out.println("La casa 2 es mejor");
        }
         
          if(casa1.esMenor(casa2)){
            System.out.println("La casa 2 es peor");
        }
        
        
    }

}
