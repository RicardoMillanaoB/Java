/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public interface Comparable <T> {

    public abstract boolean esIgual(T objeto);
    public abstract boolean esMayor(T objeto);
    public abstract boolean esMenor(T objeto);
}
