
public class Casa implements Comparable<Casa> {

    private String color;
    private int numeroVentanas;
    private int puertas;

    public Casa(String color, int numeroVentanas, int puertas) {
        this.color = color;
        this.numeroVentanas = numeroVentanas;
        this.puertas = puertas;
    }

    public String getColor() {
        return color;
    }

    public int getNumeroVentanas() {
        return numeroVentanas;
    }

    public int getPuertas() {
        return puertas;
    }

    public boolean esIgual(Casa a) {
        
        
        int cont = 0;
        if (this.color.equalsIgnoreCase(a.getColor())) {
            cont++;
        }
        if (this.numeroVentanas == a.getNumeroVentanas()) {
            cont++;
        }
        if (this.puertas == a.getPuertas()) {
            cont++;
        }

        if (cont == 3) {
            return true;
        } else {
            return false;
        }
    }

   
    public boolean esMayor(Casa a) {
        int cont = 0;
//        Casa a = (Casa) o;
         if (this.numeroVentanas  <  a.getNumeroVentanas()) {
            cont++;
        }
        if (this.puertas <  a.getPuertas()) {
            cont++;
        }

        if (cont == 2) {
            return true;
        } else {
            return false;
        }
    }

    public boolean esMenor(Casa a) {
         int cont = 0;
     
         if (this.numeroVentanas  >  a.getNumeroVentanas()) {
            cont++;
        }
        if (this.puertas >  a.getPuertas()) {
            cont++;
        }

        if (cont == 2) {
            return true;
        } else {
            return false;
        }
    }

}
