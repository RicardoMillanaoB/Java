package Paquete;

import java.util.ArrayList;
import java.util.Scanner;

public class MetodosAuxiliares {

    MetodosAuxiliares() {
    }

    public String preguntarNombre() {
        Scanner intro = new Scanner(System.in);
        System.out.println("Ingrese su nombre");
        String nombre = intro.next();
        return nombre;
    }

    public String preguntarCorreo() {
        Scanner intro = new Scanner(System.in);
        System.out.println("Ingrese su correo ");
        String correo = intro.next();
        return correo;
    }

    public String preguntarContraseña() {
        Scanner intro = new Scanner(System.in);
        String contraseña;
        System.out.println("Ingrese su contraseña");
        contraseña = intro.next();

        return contraseña;
    }

    public int opcionLogin() {
        Scanner intro = new Scanner(System.in);
        int opcion;
        do {

            opcion = intro.nextInt();
            if (opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4) {
                System.out.println("Opcion invalida, ingrese nuevamente");
            }
        } while (opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4);

        return opcion;
    }

    public int opcionIngreso() {
        int opcion;

        Scanner intro = new Scanner(System.in);
        do {
            System.out.println("1-Ingresar con cuenta\n2-Crear cuenta nueva");
            opcion = intro.nextInt();
            if (opcion != 1 && opcion != 2) {
                System.out.println("Opcion invalida, ingrese nuevamente");
            }
        } while (opcion != 1 && opcion != 2);
        return opcion;
    }

    public int opcionReservaAsiento() {
        int opcion;

        Scanner intro = new Scanner(System.in);
        do {
            System.out.println("1-Asiento normal\n2-Asiento premium\n3-Salir");
            opcion = intro.nextInt();
            if (opcion != 1 && opcion != 2) {
                System.out.println("Opcion invalida, ingrese nuevamente");
            }
        } while (opcion != 1 && opcion != 2);
        return opcion;
    }

    public int opcionAsiento() {
        Scanner intro = new Scanner(System.in);
        System.out.println("Ingrese el asiento ");
        int asiento = intro.nextInt();

        return asiento;
    }

    public int preguntarAerolinea(ArrayList<Aerolinea> listAerolineas) {
        int indice = 0;
        int cont1 = 0;
        String bandera;
        String nombreAerolinea;
        Scanner intro = new Scanner(System.in);

        System.out.println("Ingrese la aerolinea de el vuelo,");
        System.out.print("Si se olvidó de las aerolineas y del vuelo presione (S)\n");
        nombreAerolinea = intro.next();

        if (nombreAerolinea.equalsIgnoreCase("S") || nombreAerolinea.equalsIgnoreCase("s")) {
            //imprime la informacion de todos los vuelos
            for (int i = 0; i < listAerolineas.size(); i++) {
                for (int j = 0; j < listAerolineas.get(i).getListVuelos().size(); j++) {
                    System.out.println(listAerolineas.get(i).getListVuelos().get(j).toString());
                }
            }
            System.out.println("Ingrese la aerolinea");
            nombreAerolinea = intro.next();
        }

        for (int i = 0; i < listAerolineas.get(i).getListVuelos().size() - 1; i++) {
            if (nombreAerolinea.equalsIgnoreCase(listAerolineas.get(i).getNombre())) {
                indice = i;
                cont1++;
            }
        }
//        if (cont1 < 1) {
//            System.out.println("Error, ingrese el vuelo nuevamente");
//          
//          
//
//            preguntarAerolinea(listAerolineas);
//
//        }

        return indice;
    }

    public int preguntarVuelo(ArrayList<Aerolinea> listAerolineas) {
        int indice = 0;
        int idVuelo;
        int cont1 = 0;
        String bandera;
        Scanner intro = new Scanner(System.in);

        System.out.println("Ingrese el codigo de vuelo");
        
        
        idVuelo = intro.nextInt();

        for (int i = 0; i < listAerolineas.get(i).getListVuelos().size()-1; i++) {
            for (int j = 0; j < listAerolineas.get(i).getListVuelos().size()-1; j++) {
                if (listAerolineas.get(i).getListVuelos().get(j).getIdVuelo() == (idVuelo)) {
                    indice = j;
                    cont1++;
                }
            }
        }
//            if (cont1 < 1) {
//                System.out.println("Error, ingrese el vuelo nuevamente");
//             
//                    preguntarAerolinea(listAerolineas);
//                }
            
        

        return indice;
    }
    public int menu(){
        Scanner intro = new Scanner(System.in);
        int indice = 0;
        do{
        System.out.println("1-Consultas");
        System.out.println("2-Reservas");
        System.out.println("3-Compras");
        System.out.println("4-Salir");
        
        indice = intro.nextInt();
        
        if(indice!=1 && indice!=2 && indice!=3 && indice!=4){
            System.out.println("Número no permitido, ingrese nuevamente");
        }
        }while((indice!=1 && indice!=2 && indice!=3 && indice!=4));
        return indice;
    }
}
