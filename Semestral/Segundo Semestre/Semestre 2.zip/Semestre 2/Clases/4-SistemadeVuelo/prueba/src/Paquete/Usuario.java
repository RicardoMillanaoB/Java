package Paquete;

import java.util.ArrayList;


public class Usuario {
    
    private String nombre;
    private String correo;
    private String contraseña;
    private ArrayList<Billete> billete;
    private static int cont = 0;
    private int id;
    
    Usuario(String nombre, String correo, String contraseña){
        this.nombre = nombre;
        this.correo = correo;
        this.contraseña = contraseña;
        this.id = cont++;
        this.billete = new ArrayList<>();
        
    }
    Usuario(){}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public static int getCont() {
        return cont;
    }

    public static void setCont(int cont) {
        Usuario.cont = cont;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Billete> getBillete() {
        return billete;
    }

    public void setBillete(ArrayList<Billete> billete) {
        this.billete = billete;
    }

  
    

    @Override
    public String toString() {
        return "\nNombre:" + nombre + "\nCorreo:" + correo ;
    }
    
    
}
