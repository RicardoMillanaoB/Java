package Paquete;

import java.util.ArrayList;
public class Aerolinea {

    private String nombre;
    private ArrayList<Vuelo> listVuelos;
    
    Aerolinea(String nombre){
        this.nombre = nombre;
       this.listVuelos = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Vuelo> getListVuelos() {
        return listVuelos;
    }

    public void setListVuelos(ArrayList<Vuelo> listVuelos) {
        this.listVuelos = listVuelos;
    }
    
   public void añadirVuelo(Vuelo vuelo){
       this.listVuelos.add(vuelo);
   }
}
