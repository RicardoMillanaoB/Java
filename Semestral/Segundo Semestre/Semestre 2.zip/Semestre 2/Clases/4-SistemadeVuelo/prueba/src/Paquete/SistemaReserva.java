package Paquete;

import java.util.ArrayList;

public class SistemaReserva {

    private ArrayList<Usuario> listUsuarios;
    private ArrayList<Aerolinea> listAerolineas;
    public MetodosAuxiliares metodosAuxiliares;

    SistemaReserva() {
        this.listUsuarios = new ArrayList<>();
        this.listAerolineas = new ArrayList<>();
        this.metodosAuxiliares = new MetodosAuxiliares();
    }

    public ArrayList<Usuario> getListUsuarios() {
        return listUsuarios;
    }

    public void setListUsuarios(ArrayList<Usuario> listUsuarios) {
        this.listUsuarios = listUsuarios;
    }

    public ArrayList<Aerolinea> getListAerolineas() {
        return listAerolineas;
    }

    public void setListAerolineas(ArrayList<Aerolinea> listAerolineas) {
        this.listAerolineas = listAerolineas;
    }

    public void añadirUsuario(Usuario usuario) {
        listUsuarios.add(usuario);
    }

    public void añadirAerolinea(Aerolinea aerolinea) {
        this.listAerolineas.add(aerolinea);
    }

    public int login() {
    
        int opcionIngreso;

       
                opcionIngreso = metodosAuxiliares.opcionIngreso();
                if (opcionIngreso == 1) {
                    if (ingresarUsuario() == true) {
                        return listUsuarios.size() - 1;
                    } else {
                        return 0;
                    }
                } else {
                    crearUsuario();
                    return listUsuarios.size() - 1;
                }

    }

    public boolean ingresarUsuario() {
        int indice = 0;
        int cont1 = 0;
        int cont2 = 0;
        int cont3 = 0;
        String nombre;
        String correo;
        String contraseña;
        boolean bandera1 = false;
        boolean bandera2 = false;
        boolean bandera3 = false;

        for (int i = 1; i < listUsuarios.size(); i++) {//por el comodin del primer usuario que se copia la memoria en el usuario creado en algun momento

            //validacion nombre
            do {
                nombre = metodosAuxiliares.preguntarNombre();

                for (int j = 1; j < listUsuarios.size(); j++) {//por el comodin del primer usuario que se copia la memoria en el usuario creado en algun momento

                    if (nombre.equalsIgnoreCase(this.listUsuarios.get(j).getNombre())) {
                        System.out.println("Ingresando...");
                        indice = j;
                        bandera1 = true;

                    } else if (cont1 == 3) {
                        System.out.println("Intento fallido");
                        switch (cont1) {
                            case 0:
                                System.out.println("Quedan 3 intentos");
                                break;
                            case 1:
                                System.out.println("Quedan 2 intentos");
                                break;
                            case 2:
                                System.out.println("Quedan 1 intenteo");
                                break;
                            case 3:
                                System.out.println("Lo sentimos, usuario no encontrado");
                                return false;
                        }
                    }
                }
                cont1++;
            } while (cont1 != 3 && bandera1 == false);

            //validacion correo
            if (bandera1 == true) {
                do {
                    correo = metodosAuxiliares.preguntarCorreo();
                    if (correo.equalsIgnoreCase(this.listUsuarios.get(indice).getCorreo())) {
                        bandera2 = true;
                        System.out.println("Ingresando..");
                    } else {
                        System.out.println("Intento fallido");
                        switch (cont2) {
                            case 0:
                                System.out.println("Quedan 3 intentos");
                                break;
                            case 1:
                                System.out.println("Quedan 2 intentos");
                                break;
                            case 2:
                                System.out.println("Queda 1 intento");
                                break;
                            case 3:
                                System.out.println("Lo sentimos, usuario no encontrado");
                                return false;
                        }
                    }
                    cont2++;
                } while (cont2 != 3 && bandera2 == false);

                //validacion contraseña
                if (bandera2 == true) {
                    do {
                        contraseña = metodosAuxiliares.preguntarContraseña();
                        if (contraseña.equalsIgnoreCase(this.listUsuarios.get(indice).getContraseña())) {
                            bandera3 = true;
                            System.out.println("Ingresando a cuenta " + this.listUsuarios.get(indice).toString());
                            return true;
                        } else {
                            System.out.println("Intento fallido");
                            switch (cont3) {
                                case 0:
                                    System.out.println("Quedan 3 intentos");
                                    break;
                                case 1:
                                    System.out.println("Quedan 2 intentos");
                                    break;
                                case 2:
                                    System.out.println("Queda 1 intento");
                                    break;
                                case 3:
                                    System.out.println("Lo sentimos, usuario no encontrado");
                                    return false;
                            }
                        }
                        cont3++;
                    } while (cont3 != 3 && bandera3 == false);
                }
            }

        }
        return false;
    }

    public void crearUsuario() {
        
        Usuario user = new Usuario(metodosAuxiliares.preguntarNombre(),metodosAuxiliares.preguntarCorreo(),metodosAuxiliares.preguntarContraseña());
        this.listUsuarios.add(user);

    }

    public void consultas() {

        int indice = login();

        if (indice != 0) {//si es que pudo ingresar correctamente el usuario;

            System.out.println("========================================");
            System.out.println("             Consultas");
            System.out.println("========================================");
            System.out.println("Ordenar por");
            System.out.println("1-Horario de vuelo");
            System.out.println("2-Tarifas de vuelo");
            System.out.println("3-Informacion de vuelo");
            System.out.println("4-Volver al menú");

            switch (metodosAuxiliares.opcionLogin()) {
                case 1:
                    for (int i = 0; i < this.listAerolineas.size(); i++) {
                        for (int j = 0; j < this.listAerolineas.get(i).getListVuelos().size(); j++) {
                            System.out.println("Horario: " + this.listAerolineas.get(i).getListVuelos().get(j).getHorarios()
                                    + " Destino: " + this.listAerolineas.get(i).getListVuelos().get(j).getCiudadDestino()
                                    + " ,Tarifa minima $" + this.listAerolineas.get(i).getListVuelos().get(j).getTarifaNormal());

                        }
                    }
                    break;
                //fin caso 1

                case 2:
                    for (int i = 0; i < this.listAerolineas.size(); i++) {
                        for (int j = 0; j < this.listAerolineas.get(i).getListVuelos().size(); j++) {
                            System.out.println("Tarifa minima $" + this.listAerolineas.get(i).getListVuelos().get(j).getTarifaNormal()
                                    + ", Tarifa premium $" + this.listAerolineas.get(i).getListVuelos().get(j).getTarifaPremium()
                                    + ", Destino: " + this.listAerolineas.get(i).getListVuelos().get(j).getCiudadDestino());
                            break;
                        }
                    }
            
            case 3:
            for(int i = 0; i < this.listAerolineas.size(); i++){
                for(int j = 0; j < this.listAerolineas.get(i).getListVuelos().size();j++){
                    System.out.println(this.listAerolineas.get(i).getListVuelos().get(j).toString());
                }
            }
            break;
        }
        }
    }
    public void consultasVuelos(ArrayList<Aerolinea>listAerolineas){
         for(int i = 0; i < this.listAerolineas.size(); i++){
                for(int j = 0; j < this.listAerolineas.get(i).getListVuelos().size();j++){
                    System.out.println(this.listAerolineas.get(i).getListVuelos().get(j).toString());
                }
         }
    }
    
    public void reservas(){
        
        int indice = login();
        
        if(indice != 0){ 
 
            switch( metodosAuxiliares.opcionReservaAsiento()){
                case 1:
                    System.out.println("Caso 1---------------------------");
                    listAerolineas.get(metodosAuxiliares.preguntarAerolinea(this.listAerolineas)).getListVuelos().get(metodosAuxiliares.preguntarVuelo(this.listAerolineas)).reservarAsientosNormal(listUsuarios.get(indice), metodosAuxiliares.opcionAsiento());
            break;
                case 2:
                    listAerolineas.get(metodosAuxiliares.preguntarAerolinea(this.listAerolineas)).getListVuelos().get(metodosAuxiliares.preguntarVuelo(this.listAerolineas)).reservarAsientosPremium(listUsuarios.get(indice), metodosAuxiliares.opcionAsiento());
                    break;
                case 3:
                    System.out.println("Saliendo.....");
                    break;
            }
            
        }
    }
public void compras(){
     int indice = login();
        
        if(indice != 0){ 
            
            switch( metodosAuxiliares.opcionReservaAsiento()){
                case 1:
                    System.out.println("Caso 1---------------------------");
                    listAerolineas.get(metodosAuxiliares.preguntarAerolinea(this.listAerolineas)).getListVuelos().get(metodosAuxiliares.preguntarVuelo(this.listAerolineas)).comprarAsientosNormal(listUsuarios.get(indice), metodosAuxiliares.opcionAsiento());
            break;
                case 2:
                    listAerolineas.get(metodosAuxiliares.preguntarAerolinea(this.listAerolineas)).getListVuelos().get(metodosAuxiliares.preguntarVuelo(this.listAerolineas)).comprarAsientosPremium(listUsuarios.get(indice), metodosAuxiliares.opcionAsiento());
                    break;
                case 3:
                    System.out.println("Saliendo.....");
                    break;
            }
            
        }
    }
}

