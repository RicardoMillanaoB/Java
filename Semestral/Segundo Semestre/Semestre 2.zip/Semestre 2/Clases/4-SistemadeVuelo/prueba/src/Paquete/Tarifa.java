
package Paquete;


public class Tarifa {

private double tarifaNormal;
        private double tarifaPremium;
        
        Tarifa(double tarifaNormal, double tarifaPremium){
            this.tarifaNormal = tarifaNormal;
            this.tarifaPremium = tarifaPremium;
        }

    public double getTarifaNormal() {
        return tarifaNormal;
    }

    public void setTarifaNormal(double tarifaNormal) {
        this.tarifaNormal = tarifaNormal;
    }

    public double getTarifaPremium() {
        return tarifaPremium;
    }

    public void setTarifaPremium(double tarifaPremium) {
        this.tarifaPremium = tarifaPremium;
    }
        
        
}
