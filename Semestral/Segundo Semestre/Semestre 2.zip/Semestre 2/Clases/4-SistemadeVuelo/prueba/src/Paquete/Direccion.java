/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Paquete;

/**
 *
 * @author Ricardo
 */
public class Direccion {

    public static void main(String args[]) {
       MetodosAuxiliares auxiliares = new MetodosAuxiliares();
        //registro del sistema
        SistemaReserva sistema = new SistemaReserva();
       
        //registro de aerolineas
        Aerolinea lan = new Aerolinea("LAN");
        Aerolinea chileSky= new Aerolinea("Chile Sky");
        //añadir Aerolinea
        sistema.añadirAerolinea(lan);
        sistema.añadirAerolinea(chileSky);
        //Usuarios del sistema
        Usuario u0 = new Usuario("","","");
        Usuario u1 = new Usuario("Samuel", "samuel.com", "hola");
        Usuario u2 = new Usuario("Patricio", "patricio.com", "hola");
        Usuario u3 = new Usuario("Tomas", "tomas.com", "hola");
        Usuario u4 = new Usuario("Hola", "hola.com", "hola");
        //usuarios del sistema  en el ArrayList
        sistema.añadirUsuario(u0);
        sistema.añadirUsuario(u1);
        sistema.añadirUsuario(u2);
        sistema.añadirUsuario(u3);
        sistema.añadirUsuario(u4);
        
        
        //Catalogos de vuelos
        Tarifa tarifaLan1 = new Tarifa(50000,700000);
        Tarifa tarifaLan2 = new Tarifa(60000,130000);
        Tarifa tarifaChileSky1 = new Tarifa(400000,700000);
        Tarifa tarifaChileSky2 = new Tarifa(200000,350000);
        Vuelo vueloLan1 = new Vuelo(lan, "Temuco","Los Angeles,EE.UU", "8.00 - 16.00",tarifaLan1, "No", 40, 10);
        Vuelo vueloLan2 = new Vuelo(lan,"Temuco","Bueno Aires, Argentina", "10.00 - 12.00",tarifaLan2, "No", 60, 20);
        Vuelo vueloChileSky1 = new Vuelo(chileSky, "Temuco","Los Angeles,California", "8.00 - 16.00",tarifaChileSky1, "No", 40, 10);
        Vuelo vueloChileSky2= new Vuelo(chileSky, "Temuco","Los Angeles,California", "8.00 - 16.00",tarifaChileSky2, "No", 40, 10);
        //Añadir vuelos aerolineas
        lan.añadirVuelo(vueloLan1);
        lan.añadirVuelo(vueloLan2);
        chileSky.añadirVuelo(vueloChileSky1);
        chileSky.añadirVuelo(vueloChileSky2);
        
        int opcion;
        do{
            opcion = auxiliares.menu();
            switch(opcion){
                case 1: sistema.consultas(); 
                break;
                case 2: sistema.reservas();
                break;
                case 3: sistema.compras();
                break;
                case 4: 
                    System.out.println("Saliendo......");
            }
        
    }while(opcion != 4);


        
        //creacion de billetes vueloLan 1
        Billete b1 = new Billete(u1,vueloLan1,1,"Reserva clase normal");
        Billete b2 = new Billete(u2,vueloLan1,2,"Reserva clase normal");
        Billete b3 = new Billete(u3,vueloLan1,3,"Reserva clase normal");
        Billete b4 = new Billete(u4,vueloLan1,4,"Reserva clase normal");
      
        
        
    }
}
