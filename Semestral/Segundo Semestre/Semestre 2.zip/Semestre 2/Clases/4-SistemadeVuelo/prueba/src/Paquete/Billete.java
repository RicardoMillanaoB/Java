package Paquete;

public class Billete {
    
    private String usuario;
    private int numeroVuelo;
    private int numAsiento;
    private String categoriaAsiento;
    private String  aerolinea;
   
    private String ciudadOrigen;
    private String ciudadDestino;
    private String horario;
    private int idBillete = 2002;
    private static int contador = 0;
    
    Billete(Usuario usuario, Vuelo vuelo, int asiento,String categoriaAsiento){
        this.usuario = usuario.getNombre();
        this.numeroVuelo = vuelo.getIdVuelo();
       this.numAsiento = asiento;
        this.categoriaAsiento = categoriaAsiento;
        this.aerolinea = vuelo.getAerolinea();
        this.ciudadOrigen = vuelo.getCiudadOrigen();
        this.ciudadDestino = vuelo.getCiudadDestino();
        this.horario = vuelo.getHorarios();
        this.idBillete += contador++;
        
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getNumeroVuelo() {
        return numeroVuelo;
    }

    public void setNumeroVuelo(int numeroVuelo) {
        this.numeroVuelo = numeroVuelo;
    }

    public int getNumAsiento() {
        return numAsiento;
    }

    public void setNumAsiento(int numAsiento) {
        this.numAsiento = numAsiento;
    }

    public String getCategoriaAsiento() {
        return categoriaAsiento;
    }

    public void setCategoriaAsiento(String categoriaAsiento) {
        this.categoriaAsiento = categoriaAsiento;
    }

  

    public String getAerolinea() {
        return aerolinea;
    }

    public void setAerolinea(String aerolinea) {
        this.aerolinea = aerolinea;
    }

   

    public String getCiudadOrigen() {
        return ciudadOrigen;
    }

    public void setCiudadOrigen(String ciudadOrigen) {
        this.ciudadOrigen = ciudadOrigen;
    }

    public String getCiudadDestino() {
        return ciudadDestino;
    }

    public void setCiudadDestino(String ciudadDestino) {
        this.ciudadDestino = ciudadDestino;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public int getIdBillete() {
        return idBillete;
    }

    public void setIdBillete(int idBillete) {
        this.idBillete = idBillete;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Billete.contador = contador;
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena+= "n===============================================";
        cadena+="\n                Billete n° "+idBillete;
        cadena+="\n===============================================";
        cadena+="\nNombre:"+usuario;
        cadena+="\nAerolinea:"+aerolinea;
        cadena+="\nNumero de vuelo: "+numeroVuelo;
        cadena+="\nNumero asiento: "+numAsiento;
        cadena+="\nCategoria de servicio: "+categoriaAsiento;
        cadena+="\nCiudad origen: "+ciudadOrigen;
        cadena+="\nCiudad destino: "+ciudadDestino;
        cadena+="\nHorario: "+horario;
         return cadena;
    }
    
    
}
