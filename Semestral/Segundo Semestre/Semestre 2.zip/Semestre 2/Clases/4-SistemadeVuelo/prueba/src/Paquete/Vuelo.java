package Paquete;

import java.util.ArrayList;
import java.util.Scanner;

public class Vuelo {

    private String aerolinea;
    private String ciudadOrigen;
    private String ciudadDestino;
    private String horarios;
    private String escalas;
    private double tarifaNormal;
    private double tarifaPremium;
    private static int cont = 0;
    private int idVuelo = 1031;

    private Usuario reservaClaseNormal[];
    private Usuario reservaClasePremium[];
    private Usuario compraClaseNormal[];
    private Usuario compraClasePremium[];
    private int asientosClaseNormal;
    private int asientosClasePremium;
    private MetodosAuxiliares mAuxiliares;

    Vuelo(Aerolinea aerolinea, String ciudadOrigen, String ciudadDestino, String horarios, Tarifa tarifa, String escalas, int capacidadClaseNormal, int capacidadClasePremium) {
        this.aerolinea = aerolinea.getNombre();
        this.ciudadOrigen = ciudadOrigen;
        this.ciudadDestino = ciudadDestino;
        this.horarios = horarios;
        this.escalas = escalas;
        this.tarifaNormal = tarifa.getTarifaNormal();
        this.tarifaPremium = tarifa.getTarifaPremium();
        this.idVuelo += cont++;
        this.asientosClaseNormal = capacidadClaseNormal;
        this.asientosClasePremium = capacidadClasePremium;

        this.reservaClaseNormal = new Usuario[capacidadClaseNormal];
        this.reservaClasePremium = new Usuario[capacidadClasePremium];
        this.compraClaseNormal = new Usuario[capacidadClaseNormal];
        this.compraClasePremium = new Usuario[capacidadClasePremium];
        this.mAuxiliares = new MetodosAuxiliares();

    }

    public String getAerolinea() {
        return aerolinea;
    }

    public void setAerolinea(String aerolinea) {
        this.aerolinea = aerolinea;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

    public String getEscalas() {
        return escalas;
    }

    public void setEscalas(String escalas) {
        this.escalas = escalas;
    }

    public Object[] getReservaClaseNormal() {
        return reservaClaseNormal;
    }

   

    public String getCiudadOrigen() {
        return ciudadOrigen;
    }

    public void setCiudadOrigen(String ciudadOrigen) {
        this.ciudadOrigen = ciudadOrigen;
    }

    public String getCiudadDestino() {
        return ciudadDestino;
    }

    public void setCiudadDestino(String ciudadDestino) {
        this.ciudadDestino = ciudadDestino;
    }

    public double getTarifaNormal() {
        return tarifaNormal;
    }

    public void setTarifaNormal(double tarifaNormal) {
        this.tarifaNormal = tarifaNormal;
    }

    public double getTarifaPremium() {
        return tarifaPremium;
    }

    public void setTarifaPremium(double tarifaPremium) {
        this.tarifaPremium = tarifaPremium;
    }

    public int getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(int idVuelo) {
        this.idVuelo = idVuelo;
    }

    public int getAsientosClaseNormal() {
        return asientosClaseNormal;
    }

    public void setAsientosClaseNormal(int asientosClaseNormal) {
        this.asientosClaseNormal = asientosClaseNormal;
    }

    public int getAsientosClasePremium() {
        return asientosClasePremium;
    }

    public void setAsientosClasePremium(int asientosClasePremium) {
        this.asientosClasePremium = asientosClasePremium;
    }

    public void reservarAsientosNormal(Usuario usuario, int asiento) {

        int cont1 = 0;
        int cont2 = 0;
        String disponibilidad;
        Scanner intro = new Scanner(System.in);
        //registra al usuario en el arreglo de reservacion 
        for (int i = 0; i < this.reservaClaseNormal.length; i++) {
            if (this.reservaClaseNormal[i] == null) {
                cont1++;
            }
        }
        for (int j = 0; j < this.reservaClaseNormal.length; j++) {
            if (this.compraClaseNormal[j] == null) {
                cont2++;
            }
        }

        if (this.reservaClaseNormal.length < (cont1 + cont2)) {

            if (this.reservaClaseNormal[asiento+1] == null) {

                System.out.println("Esta dispuesto a pagar (S / N )$" + this.tarifaNormal);
                disponibilidad = intro.next();

                if (disponibilidad.equalsIgnoreCase("n") || disponibilidad.equalsIgnoreCase("N")) {
                    System.out.println("Saliendo...");
                    return;
                } else {

                    reservaClaseNormal[asiento+1] = usuario;
                    Billete b = new Billete(usuario,this,asiento,"Reserva clase normal");
                    System.out.println(b.toString());
                    
                }
            } else {
                System.out.println("Asiento disponibles: ");
                for (int k = 0; k < this.reservaClaseNormal.length; k++) {
                    if (this.reservaClaseNormal[k] == null) {
                        System.out.print(k + "-");
                    }
                    reservarAsientosNormal(usuario, mAuxiliares.opcionAsiento());
                }
            }
        } else {
            System.out.println("No quedan cupos");
        }
    }

    public void reservarAsientosPremium(Usuario usuario, int asiento) {
         int cont1 = 0;
        int cont2 = 0;
        String disponibilidad;
        Scanner intro = new Scanner(System.in);
        //registra al usuario en el arreglo de reservacion 
        for (int i = 0; i < this.reservaClasePremium.length; i++) {
            if (this.reservaClasePremium[i] == null) {
                cont1++;
            }
        }
        for (int j = 0; j < this.compraClasePremium.length; j++) {
            if (this.compraClasePremium[j] == null) {
                cont2++;
            }
        }

        if (reservaClasePremium.length < (cont1 + cont2)) {

            if (this.reservaClasePremium[asiento+1] == null) {

                System.out.println("Esta dispuesto a pagar (S / N )$" + this.tarifaNormal);
                disponibilidad = intro.next();

                if (disponibilidad.equalsIgnoreCase("n") || disponibilidad.equalsIgnoreCase("N")) {
                    return;
                } else {

                    reservaClasePremium[asiento+1] = usuario;
                    Billete b = new Billete(usuario, this, asiento,"Rerserva clase premium");
                    System.out.println(b.toString());
                }
            } else {
                System.out.println("Asiento disponibles: ");
                for (int k = 0; k < this.reservaClasePremium.length; k++) {
                    if (this.reservaClasePremium[k] == null) {
                        System.out.print(k + "-");
                    }
                    reservarAsientosPremium(usuario, mAuxiliares.opcionAsiento());
                }
            }
        } else {
            System.out.println("No quedan cupos");
        }

    }

    public void comprarAsientosNormal(Usuario usuario, int asiento) {
        int cont1 = 0;
        int cont2 = 0;
        String disponibilidad;
        Scanner intro = new Scanner(System.in);
        //registra al usuario en el arreglo de reservacion 
        for (int i = 0; i < this.compraClaseNormal.length; i++) {
            if (this.compraClaseNormal[i] == null) {
                cont1++;
            }
        }
        for (int j = 0; j < this.reservaClaseNormal.length; j++) {
            if (this.reservaClaseNormal[j] == null) {
                cont2++;
            }
        }

        if (compraClaseNormal.length < (cont1 + cont2)) {

            if (this.compraClaseNormal[asiento+1] == null) {

                System.out.println("Esta dispuesto a pagar (S / N )$" + this.tarifaNormal);
                disponibilidad = intro.next();

                if (disponibilidad.equalsIgnoreCase("n") || disponibilidad.equalsIgnoreCase("N")) {
                    return;
                } else {

                    compraClaseNormal[asiento+1] = usuario;
                    Billete b = new Billete(usuario, this, asiento,"Compra clase normal");
                    System.out.println(b.toString());
                }
            } else {
                System.out.println("Asiento disponibles: ");
                for (int k = 0; k < this.compraClaseNormal.length; k++) {
                    if (this.compraClaseNormal[k] == null) {
                        System.out.print(k + "-");
                    }
                    comprarAsientosNormal(usuario, mAuxiliares.opcionAsiento());
                }
            }
        } else {
            System.out.println("No quedan cupos");
        }
    }

    public void comprarAsientosPremium(Usuario usuario, int asiento) {
         int cont1 = 0;
        int cont2 = 0;
        String disponibilidad;
        Scanner intro = new Scanner(System.in);
        //registra al usuario en el arreglo de reservacion 
        for (int i = 0; i < this.compraClasePremium.length; i++) {
            if (this.compraClasePremium[i] == null) {
                cont1++;
            }
        }
        for (int j = 0; j < this.reservaClasePremium.length; j++) {
            if (this.reservaClasePremium[j] == null) {
                cont2++;
            }
        }

        if (compraClasePremium.length < (cont1 + cont2)) {

            if (this.compraClasePremium[asiento+1] == null) {

                System.out.println("Esta dispuesto a pagar (S / N )$" + this.tarifaNormal);
                disponibilidad = intro.next();

                if (disponibilidad.equalsIgnoreCase("n") || disponibilidad.equalsIgnoreCase("N")) {
                    return;
                } else {

                    this.compraClasePremium[asiento+1] = usuario;
                    Billete b = new Billete(usuario, this, asiento,"Compra clase premium");
                    System.out.println(b.toString());
                }
            } else {
                System.out.println("Asiento disponibles: ");
                for (int k = 0; k < this.compraClasePremium.length; k++) {
                    if (this.compraClasePremium[k] == null) {
                        System.out.print(k + "-");
                    }
                    comprarAsientosPremium(usuario, mAuxiliares.opcionAsiento());
                }
            }
        } else {
            System.out.println("No quedan cupos");
        }
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "=================================================\n";
        cadena += "       Aerolinea: " + aerolinea;
        cadena += "  -  Vuelo: " + idVuelo;
        cadena += "\nCiudad origen: " + ciudadOrigen + "\nCiudad destino: " + ciudadDestino + "\nHorarios: " + horarios + "\nEscalas: " + escalas + "\nTarifa normal: $" + tarifaNormal + "\nTarifa premium: $" + tarifaPremium + "\nAsientos en clase normal: " + asientosClaseNormal + "\nAsientos clase premium: " + asientosClasePremium;
        return cadena;
    }

}
