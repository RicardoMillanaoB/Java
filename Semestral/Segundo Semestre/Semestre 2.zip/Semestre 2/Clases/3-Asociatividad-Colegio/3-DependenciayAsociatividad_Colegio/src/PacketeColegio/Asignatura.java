package PacketeColegio;

public class Asignatura {

    private String nombre;
    private int capacidad;
    private Profesor profesor;
    private Alumno[] alumno;

    Asignatura(String nombre, int capacidad, Profesor profesor) {
        this.nombre = nombre;
        this.profesor = profesor;
       this.capacidad = capacidad;
       
         this.profesor.getAsignaturas().add(this);
          this.alumno = new Alumno[capacidad];
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Alumno[] getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno[] alumno) {
        this.alumno = alumno;
    }

    //funciones propias
    public void agregarAlumno(Alumno alumno) {
        for (int i = 0; i < this.alumno.length; i++) {
            if (this.alumno[i] == null) {
                this.alumno[i] = alumno;
                return;
            }
        }
        System.out.println("Asignatura llena");
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "\n==================================\n";
        cadena += this.nombre;
        cadena += "\n==================================\n";
        cadena += "Con capacidad para" + this.alumno.length + "estudiantes";
        cadena += "\nLista de alumnos:\n";
        
        for (int i = 0; i < this.alumno.length; i++) {
            if (this.alumno[i] != null) {
                cadena += alumno[i].toString();
            }
        }
        cadena += "\nProfesor" + profesor;
        return cadena;
    }

}
