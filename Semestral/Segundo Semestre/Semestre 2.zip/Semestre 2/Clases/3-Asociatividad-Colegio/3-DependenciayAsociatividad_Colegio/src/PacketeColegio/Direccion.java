package PacketeColegio;

public class Direccion {

    public static void main(String[] args) {

        Colegio c = new Colegio("El lechuga");
        
        Alumno a1 = new Alumno("Joaquin Sepuelveda", "203434343");
        Alumno a2 = new Alumno("Miguel Ceres", "2012312312");
        Alumno a3 = new Alumno("Diego Urzua", "203434353");
        Alumno a4 = new Alumno("Macarena Lopez", "2013452312");
        
       Profesor p1 = new Profesor("Don Esteban Lopez", 4000000);
       Profesor p2 = new Profesor("Don Samuel Vargas",3000000);
       
       Asignatura asig1 = new Asignatura("Histologia",3,p1);
       
       c.matricularAlumno(a1);
       c.matricularAlumno(a2);
       c.matricularAlumno(a3);
       c.matricularAlumno(a4);
       
       c.inscribirProfesor(p1);
       c.inscribirProfesor(p2);
       
       c.inscribirAsignatura(asig1);
       
       asig1.agregarAlumno(a1);
       asig1.agregarAlumno(a2);
       asig1.agregarAlumno(a3);
       asig1.agregarAlumno(a4);
      
       
        System.out.println(c.toString());

    }

}
