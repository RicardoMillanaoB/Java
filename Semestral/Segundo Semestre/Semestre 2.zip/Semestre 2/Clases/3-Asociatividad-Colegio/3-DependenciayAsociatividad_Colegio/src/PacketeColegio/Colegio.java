package PacketeColegio;

import java.util.ArrayList;

public class Colegio {

    private String nombre;
    private ArrayList<Alumno> alumnos;
    private ArrayList<Profesor> profesores;
    private Asignatura[] asignatura;

    Colegio(String nombre) {
        this.nombre = nombre;
        this.alumnos = new ArrayList<>();
        this.profesores = new ArrayList<>();
        this.asignatura = new Asignatura[10];
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Alumno> getAlumnos() {
        return alumnos;
    }

    public void setAlumnos(ArrayList<Alumno> alumnos) {
        this.alumnos = alumnos;
    }

    public ArrayList<Profesor> getProfesores() {
        return profesores;
    }

    public void setProfesores(ArrayList<Profesor> profesores) {
        this.profesores = profesores;
    }

    public Asignatura[] getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(Asignatura[] asignatura) {
        this.asignatura = asignatura;
    }

    //funciones propias
    public void inscribirAsignatura(Asignatura asignatura) {
        for (int i = 0; i < this.asignatura.length; i++) {
            if (this.asignatura[i] == null) {
                this.asignatura[i] = asignatura;
                break;
            } else {
                System.out.println("Ha sobrepasado la cantidad de asignaturas");
            }       
        }
    }
    
    public void matricularAlumno(Alumno alumno){
        this.alumnos.add(alumno);
    }
    
    public void inscribirProfesor(Profesor profesor){
        this.profesores.add(profesor);
    }

    @Override
    public String toString() {
        String cadena = "";
         cadena+= "\n==================================";
         cadena+= "\n     "+nombre;
          cadena+= "\n==================================";
          cadena+= "\nAsignaturas";
          for(int i = 0; i < this.asignatura.length; i++){
              if(this.asignatura[i] != null){
                  cadena+= this.asignatura[i].toString();
              }
          }
          
        return cadena;
    }

    
}
