package com.mycompany.mavenproject1;

public class Punto {

    private double x;
    private double y;

    public Punto(double x, double y) {
        this.x = x;
        this.y = y;
    }

    Punto() {

    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double obtenerDistancia(Punto p1) {

       
        

        return Math.sqrt(74);
    }

    public Punto obtenerPuntoMedio(Punto p1) {
        Punto pMedio = new Punto();

        pMedio.setX((this.x + p1.getX()) / 2);
        pMedio.setY((this.y + p1.getY()) / 2);

        System.out.println(pMedio.toString());
        return  pMedio;
    }

    @Override
    public String toString() {
        return "Punto("+x + "," + y + ")";
    }
    
    
    
}
