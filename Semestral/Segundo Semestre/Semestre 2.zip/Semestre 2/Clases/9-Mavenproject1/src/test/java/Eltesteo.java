/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mycompany.mavenproject1.Punto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class Eltesteo {

    Punto p1;
    Punto p2;

    public Eltesteo() {
    }

    @Before
    public void setUp() {
        p1 = new Punto(7, 5);
        p2 = new Punto(7, 5);
    }

    @Before
    public void testObtenerPuntoMedio() {

        Punto resultadoEsperado = new Punto(7.0, 5.0);
        Punto resultadoObtenido = p1.obtenerPuntoMedio(p2);

        //assertTrue(resultadoEsperado.equal(resultadoObtenido)));
        assertEquals(resultadoEsperado, resultadoObtenido);
    }

    @Test
    public void testObtenerDistancia() {
        Punto p = new Punto(0, 0);
        double esperado = Math.sqrt(74);
        double resultado = p1.obtenerDistancia(p);
        assertEquals(esperado, resultado);
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
