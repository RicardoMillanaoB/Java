
package paquete;


public class Obrero extends Empleado{

    Obrero(String nombre, int sueldo){
        super(nombre,sueldo);
    }
    Obrero(String nombre, int sueldoBase, int sueldo){
        super(nombre,sueldoBase);
        super.setSueldo(sueldo);
    }
 

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return "\n"+super.getNombre()+"\nSueldo: "+sueldo
                ;
    }
    
    
    
}
