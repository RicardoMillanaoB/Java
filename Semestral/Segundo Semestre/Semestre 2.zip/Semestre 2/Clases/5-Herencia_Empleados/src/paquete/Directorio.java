package paquete;

public class Directorio {

    public static void main(String args [] ){
    Empleado e= new Empleado("Juan Perez",300000);
    
   Obrero o1 = new Obrero("Fernando Rebarren",20000);
        System.out.println(o1.imprimirDatos());
    

    }
}
