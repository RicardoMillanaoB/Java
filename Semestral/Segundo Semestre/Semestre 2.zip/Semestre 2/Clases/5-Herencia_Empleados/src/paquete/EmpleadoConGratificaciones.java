
package paquete;


public class EmpleadoConGratificaciones extends Empleado{

    protected int montoGratificacion;
    
    EmpleadoConGratificaciones(String nombre, int sueldoBase,int montoGratificacion){
        super(nombre,sueldoBase);
        this.montoGratificacion = montoGratificacion;
    }

    public int getMontoGratificacion() {
        return montoGratificacion;
    }

    public void setMontoGratificacion(int montoGratificacion) {
        this.montoGratificacion = montoGratificacion;
    }
    
}
