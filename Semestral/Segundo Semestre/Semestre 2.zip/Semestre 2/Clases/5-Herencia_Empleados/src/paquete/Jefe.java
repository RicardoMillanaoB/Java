package paquete;

public class Jefe extends EmpleadoConGratificaciones {

    Jefe(String nombre, int sueldoBase, int montoGratificacion) {
        super(nombre,sueldoBase,montoGratificacion);
    }

    public int calcularSueldo() {
        int sueldo = 0;

        return sueldo;
    }

    public String imprimirDatos() {
        return super.imprimirDatos();
    }

}
