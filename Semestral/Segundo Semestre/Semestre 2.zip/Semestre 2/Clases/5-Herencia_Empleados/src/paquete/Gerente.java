
package paquete;


public class Gerente extends EmpleadoConGratificaciones{

    private int bonoAnual;
    
    Gerente(String nombre,int sueldoBase,int montoGratificaciones, int bono){
        super(nombre,sueldoBase,montoGratificaciones);
        this.bonoAnual = bono;
    }

    public int getBonoAnual() {
        return bonoAnual;
    }

public int calcularSueldo(){
    int sueldo = 0;
    
    return sueldo;
}
public String imprimirDatos(){
    return this.imprimirDatos()+" \nBono anual: $"+this.bonoAnual;
}
    
    
}
