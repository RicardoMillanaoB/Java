
public class Animal {
    
    private String nombre;
    private 
}
