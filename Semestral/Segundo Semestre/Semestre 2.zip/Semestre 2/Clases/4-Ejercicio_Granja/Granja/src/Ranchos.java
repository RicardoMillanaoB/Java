import java.util.ArrayList;
public class Ranchos {
    
    private String nombre;
    private Animal animal;
    
    Ranchos(String nombre, Animal animal){
        this.nombre = nombre;
        this.animal = animal;
    }
    
}
