
package paquete;


public class Cuadrado extends Figura {

    private int lado;
    
    Cuadrado(int lado){
        this.lado  = lado;
        
    }
    @Override
    public double area(){
        return Math.pow(lado, 2);
    }
    @Override
    public double perimetro(){
        return lado*4;
    }
}
