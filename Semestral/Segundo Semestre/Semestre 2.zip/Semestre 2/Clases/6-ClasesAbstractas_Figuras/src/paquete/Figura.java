
package paquete;


public abstract class Figura {

private String color;


public double area(){
    return 0;
}
public double perimetro(){
    return 0;
}


}
