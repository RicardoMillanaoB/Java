
package paquete;


public class Triangulo extends Figura{

    private int lado1;
    private int lado2;
    private String tipo;
    private int base;
    private int altura;

    public Triangulo(int lado1, int lado2, String tipo, int base, int altura) {
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.tipo = tipo;
        this.base = base;
        this.altura = altura;
    }

    @Override
    public double area(){
        return (base*altura)/2;
    }
   @Override
   public double perimetro(){
       return lado1+lado2+base;
   }
}
