
package paquete;

import java.util.ArrayList;


public class Gestion {

    public void main(String [] args){
        
        ArrayList<Figura> figuras = new ArrayList<Figura>();
        
        Figura a = new Circulo(2,"rojo");
        
        figuras.add(a);
        
        for(int i = 0; i < figuras.size(); i++){
            //metodos de obtenion
        }
    }
}
