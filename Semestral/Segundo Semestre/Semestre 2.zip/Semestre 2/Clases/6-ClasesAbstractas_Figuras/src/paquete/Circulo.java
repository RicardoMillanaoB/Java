
package paquete;


public class Circulo extends Figura {

    private int radio;
    private int diametro;

    public Circulo(int radio,String color){
        super(color);
        this.radio = radio;

    }
    
    @Override
    public double area(){
        return 2*Math.PI * this.radio;
    }
    @Override
    public double perimetro(){
        return Math.PI*(Math.pow(radio,2));
    }
    public int getDiametro(){
        return radio*2;
    }
    public int getRadio(){
        return this.radio;
    }
}
