package recursividad_fibonacci;

import java.util.Scanner;
public class Recursividad_Fibonacci {

    public static void main(String[] args) {
        Scanner intro = new Scanner(System.in);
        
        System.out.println("Ingrese el número");
       int numero = intro.nextInt();
        System.out.println("La fibonacci del número es "+fibonacci(numero));
    }
public static int fibonacci(int numero){
    if(numero <= 1){
        return numero;
    }else{
        return fibonacci(numero-1)+fibonacci(numero-2);
    }
}
    
}
