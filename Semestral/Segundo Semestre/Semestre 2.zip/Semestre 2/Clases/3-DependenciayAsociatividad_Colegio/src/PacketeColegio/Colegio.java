
package PacketeColegio;

import java.util.ArrayList;


public class Colegio {

    private String nombre;
    private ArrayList<Alumno>alumnos;
    private ArrayList<Profesor> profesores;
    private Asignatura [] asignaturas;
    
    Colegio(String nombre){
        this.nombre = nombre;
        this.alumnos = new ArrayList<>();
        this.profesores = new ArrayList<>();
        this.asignaturas = new Asignatura [10];
    }
    
    
    public void inscribirAsignatura(Asignatura  asignatura){
        for(int i = 0; i < 10; i++){
            if(this.asignaturas[i] == null){
                this.asignaturas[i] = asignatura;
                return;
            }
        }
        System.out.println("No se admiten mas asignaturas");
    }
    public void matricularAlumno(Alumno alumno){
        this.alumnos.add(alumno);
    }
    public void ingresarProfesor(Profesor profesor){
        this.profesores.add(profesor);
    }
}
