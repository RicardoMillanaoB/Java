package PacketeColegio;


public class Direccion {

    public static void main(String[] args) {
      //  Alumno arreglo[] = new Alumno [10];
       //   System.out.println(arreglo[0]); // devuelve null
    }
    
    

}
