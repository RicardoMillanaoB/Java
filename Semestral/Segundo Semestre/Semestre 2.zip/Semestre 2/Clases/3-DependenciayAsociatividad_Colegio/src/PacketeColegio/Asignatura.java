package PacketeColegio;


public class Asignatura {

    private String nombre;
    private int capacidad;
    private Alumno [] alumno;
    private Profesor profesor;
    
    Asignatura(String nombre, int capacidad, Profesor profesor){
        this.nombre = nombre;
        this.alumno = new Alumno[capacidad];
        this.profesor.getAsignaturas().add(this);
        
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public Alumno[] getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno[] alumno) {
        this.alumno = alumno;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }
   
  
}

