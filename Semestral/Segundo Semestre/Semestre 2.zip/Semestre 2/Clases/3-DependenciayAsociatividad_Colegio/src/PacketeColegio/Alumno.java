
package PacketeColegio;


public class Alumno {

    private String nombre;
    private String matricula;
    
    Alumno(String nombre, String matricula){
        this.nombre = nombre;
        this.matricula = matricula;
    }
}
