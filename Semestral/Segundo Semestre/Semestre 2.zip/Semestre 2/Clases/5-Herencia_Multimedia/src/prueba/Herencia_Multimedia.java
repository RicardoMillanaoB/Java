package prueba;

import clases.*;

public class Herencia_Multimedia {

    public static void main(String[] args) {
        ListaMultimedia listaMultimedia = new ListaMultimedia();
        Multimedia multimedia = new Multimedia("Cyberpunk", "Rubenecci", "6 horas", Formato.AVI);

        //Parte 4//
        Pelicula pelicula1 = new Pelicula("Tye Sheridan", "Ready Player One", "Steven Spielberg", "2.7 horas", Formato.WAV);
        listaMultimedia.agregar(pelicula1);
        Pelicula pelicula2 = new Pelicula("Tom Cruise", "Mision Imposible", "Brian De Palma", "2.5 horas", Formato.WAV);
        listaMultimedia.agregar(pelicula2);
        Pelicula pelicula3 = new Pelicula(Formato.WAV, "Emma Watson", "La Bella y la Bestia", "Bill Condon", "3 horas");
        listaMultimedia.agregar(pelicula3);

        //imprime la listaMultimedia
        System.out.println(listaMultimedia.toString());

        //Buscar la posicion del objeto en la lista
        listaMultimedia.obtenerObjeto(1);

        //Buscar la posicicion del objeto en la lista
        System.out.println(listaMultimedia.obtenerObjeto(1).toString());
        System.out.println("Esta en la posicion: " + listaMultimedia.obtenerIndice(listaMultimedia.obtenerObjeto(1)));

                                                                              //Parte 5 //
        Disco disco1 = new Disco(Genero.ROCK, "1", "The Beatles", "32 min", Formato.MP3);
        listaMultimedia.agregar(disco1);
        Disco disco2 = new Disco(Genero.ROCK, "Revolver", "The Beatles", "36 min", Formato.MP3);
        listaMultimedia.agregar(disco2);
        Disco disco3 = new Disco(Genero.ROCK, "Let it Be", "The Beatles", "30 min", Formato.MP3);
        listaMultimedia.agregar(disco3);
        
        //imprime la listaMultimedia
        System.out.println(listaMultimedia.toString());
        
         //Buscar la posicion del objeto en la lista
        listaMultimedia.obtenerObjeto(4);

        //Buscar la posicicion del objeto en la lista
       
        System.out.println(listaMultimedia.obtenerObjeto(4).toString());
        System.out.println("Esta en la posicion: " + listaMultimedia.obtenerIndice(listaMultimedia.obtenerObjeto(4)));
        
        
    }

}
