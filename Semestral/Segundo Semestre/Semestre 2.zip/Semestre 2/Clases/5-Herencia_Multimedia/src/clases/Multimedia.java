package clases;

import java.util.ArrayList;

public class Multimedia {

    private String titulo;
    private String autor;
    private String duracion;

    private Formato formato;

    public Multimedia(String titulo, String autor, String duracion, Formato formato) {
        this.titulo = titulo;
        this.autor = autor;
        this.duracion = duracion;
        this.formato = formato;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getDuracion() {
        return duracion;
    }

    public Formato getFormato() {
        return formato;
    }

    @Override
    public String toString() {
        String cadena = "";
        cadena += "\n=======================================";
        cadena += "\n         Titulo: " + this.titulo;
        cadena += "\n=======================================";
        cadena += "\nAutor: " + this.autor;
        cadena += "\nDuracion: " + this.duracion;
        cadena += "\nFormato: " + this.formato;
        return cadena;
    }

}
