
package clases;


public enum Genero {

    ROCK,
    POP,
    FUNK;
}
