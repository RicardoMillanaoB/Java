
package clases;


public class Disco extends Multimedia {

    private Genero genero;

    public Disco(Genero genero, String titulo, String autor, String duracion, Formato formato) {
        super(titulo, autor, duracion, formato);
        this.genero = genero;
    }

    public Genero getGenero() {
        return genero;
    }

    @Override
    public String toString() {
        String cadena = super.toString();
        cadena+="\n            Musica";
        cadena+="\nGenero: "+this.genero;
        return cadena;
    }
    
    
   
}
