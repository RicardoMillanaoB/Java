package clases;

import java.util.ArrayList;

public class ListaMultimedia {

    private ArrayList<Multimedia> listaMultimedia;

    public ListaMultimedia() {
        this.listaMultimedia = new ArrayList<Multimedia>();
    }
    //metodos

    public int tam() {
        return this.listaMultimedia.size();
    }

    public boolean agregar(Multimedia archivo) {

        if (tam() != 20) {
            this.listaMultimedia.add(archivo);

            return true;
        } else {
            return false;
        }

    }

    public Multimedia obtenerObjeto(int i) {

        return this.listaMultimedia.get(i);
    }

    public int obtenerIndice(Multimedia multimedia) {

        return listaMultimedia.indexOf(multimedia);
    }

    @Override
    public String toString() {
        String cadena = "\n";

        for (int i = 0; i < listaMultimedia.size(); i++) {
            cadena += "\n" + listaMultimedia.get(i).toString();
        }
        return cadena;
    }

    public ArrayList<Multimedia> getListaMultimedia() {
        return listaMultimedia;
    }

}
