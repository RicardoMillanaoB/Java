
package clases;


public class Pelicula extends Multimedia {

    private String actorPrincipal = "No tiene actor principal";
    private String actrizPrincipal = "No tiene actriz principal";

  Pelicula(String actorPrincipal, String actrizPrincipal, String titulo, String autor, String duracion, Formato formato) {
        super(titulo, autor, duracion, formato);
        this.actorPrincipal = actorPrincipal;
        this.actrizPrincipal = actrizPrincipal;
    }
      public Pelicula(String actorPrincipal, String titulo, String autor, String duracion, Formato formato) {
        super(titulo, autor, duracion, formato);
        this.actorPrincipal = actorPrincipal;

    }
        public Pelicula(Formato formato,String actrizPrincipal, String titulo, String autor, String duracion) {
        super(titulo, autor, duracion, formato);
        this.actrizPrincipal = actrizPrincipal;

    }
       
    public String getActorPrincipal() {
        return actorPrincipal;
    }

    public String getActrizPrincipal() {
        return actrizPrincipal;
    }

    @Override
    public String toString() {
       
        String cadena="";
        cadena+= super.toString();
        cadena+= " \n             Pelicula";
        cadena+= " \nActor principal: "+actorPrincipal;
        cadena+= " \nActriz principal: "+actrizPrincipal;
        
        return cadena;
    }
    
    
}
