package tarea_jarradecafe;


public class Cafetera {

double capacidadMaxima;
double cantidadActual;
}
