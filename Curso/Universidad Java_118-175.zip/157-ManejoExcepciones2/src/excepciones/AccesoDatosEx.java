
package excepciones;


public class AccesoDatosEx extends Exception{
    //tipo de excepciones cheException 
    
    public AccesoDatosEx(String mensaje){
        super(mensaje);
    }
    
}
