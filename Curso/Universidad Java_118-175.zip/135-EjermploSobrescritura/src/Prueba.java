
public class Prueba {

    public static void main(String[] args) {

        Empleado empleado1 = new Empleado("Esteban", 12000);
        Gerente gerente1 = new Gerente("Toman Echaurruen", 600000, "Gerencia general");
        System.out.println("Empleado1");

        imprimirDetalles(empleado1);
        System.out.println("Gerente");
        imprimirDetalles(gerente1);
       

    }

    public static void imprimirDetalles(Empleado emp) {
        System.out.println(emp.obtenerDetalles()); // aqui ocurre el polimorfismo, declarando un objeto como un objeto padre
    }

}
