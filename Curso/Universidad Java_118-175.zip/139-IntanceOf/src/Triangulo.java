

public class Triangulo extends FiguraGeometrica {

    public void dibujar(){
        System.out.println("Dibujar Triangulo");
    }
    
}
