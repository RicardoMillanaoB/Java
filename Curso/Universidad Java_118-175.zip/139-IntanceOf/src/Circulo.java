

public class Circulo extends FiguraGeometrica{

    public void dibujar(){
        System.out.println("Dibujar circulo");
    }
    
}
