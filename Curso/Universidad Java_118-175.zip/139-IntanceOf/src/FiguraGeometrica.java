

public class FiguraGeometrica {
    
    
    public void dibujar(){
        System.out.println("Dibujar figura geomatrica");
    }
}
