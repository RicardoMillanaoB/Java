

public class Elipse extends Circulo{

    public void dibujar(){
        System.out.println("Dibujar elipse");
    }
}
