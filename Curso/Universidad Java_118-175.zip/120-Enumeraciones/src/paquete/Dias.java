
package paquete;


public enum Dias {
    
    //son valores contantes
    
    LUNES, MARTES,
    MIERCOLES, JUEVES,
    VIERNES,SABADO,
    DOMINGO
    
}
